(function(){
  var module = angular.module('app');
  
  module.component("metHeader", {
    bindings: {},
    controller: function() {},
    templateUrl: 'app/components/header/headerTemplate.html'
  });
}());