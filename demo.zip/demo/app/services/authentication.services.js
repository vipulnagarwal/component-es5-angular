(function(){
  var module = angular.module("app");
  
  module.service('commonUtilityService', function() {
	  console.log("commonUtilityService");
  });
  
}());