(function(){
  var module = angular.module("app");
  
  module.service('requestResolverService', function() {
	  console.log("requestResolverService");
  });
  
}());