(function(){
  var module = angular.module("app");
  
  module.service('authenticationService', function() {
	  console.log("authenticationService");
  });
  
}());