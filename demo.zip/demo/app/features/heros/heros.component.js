(function(){
  var module = angular.module('heros', []);
  
  module.component("heroContainer", {
    bindings: {},
    controller: 'app/features/heros/hero.controller.js',
    controllerAs: 'heroctrl',// if we skip, will default to $ctrl
    templateUrl: 'app/features/heros/heroTemplate.html'
  });
}());