(function(){
  var module = angular.module('villains');
  module.component('villainList', {
    bindings: { // bind right to this in controller
      villains: '=',
      onSelect: '&', // function takes single argument of villainId
      isSelected: '&' // function takes single argument of villain
    },
    templateUrl: 'app/features/villains/components/villainList/villainList.html',
    controller: function() {
    	console.log("villainList Controller called");
  	  debugger;
    },
    controllerAs: 'vm'
  });
}());