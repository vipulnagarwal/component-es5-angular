(function(){
  var module = angular.module('villains');
  module.component('villainLeaderboard', {
    bindings: { // bind right to this in controller
      villains: '='
    },
    templateUrl: 'app/features/villains/components/villainLeaderboard/villainLeaderboard.html',
    controller: function() {
    	console.log("villainLeaderboard Controller called");
    	  debugger;
    },
    controllerAs: 'vm'
  });
}());