(function(){
  var module = angular.module('villains', []);
  
  module.component("villainContainer", {
    bindings: {},
    controller: 'app/features/villains/villains.controller.js',
    controllerAs: 'ctrl',// if we skip, will default to $ctrl
    templateUrl: 'app/features/villains/villainTemplate.html'
  });
}());