//(function(){
	debugger;
angular.module("villains").controller('villainsController',['villainService', function(villainService) {
	  
	  console.log("villainsController called");
	  debugger;
	  
    var ctrl = this;
    
    // getting the villains (maybe from an API)
    var villains = villainService.query();
    
    // store the selected villain in the list to view details of
    var selectedVillain;
    setSelectedVillain(villains[0]);
  
    this.selectVillain = function(villainId) {
      setSelectedVillain(getVillain(villainId));
    };
    
    this.isVillainSelected = function(villain) {
      return (villain.id === selectedVillain.id);
    };
    
    this.moreCreepy = function(villainId) {
      var villain = getVillain(villainId);
      villain.creepy++;
    };
    
    this.lessCreepy = function(villainId) {
      var villain = getVillain(villainId);
      villain.creepy--;
    };
    
    this.changeCreepy = function(villainId, creepy) {
      var villain = getVillain(villainId);
      villain.creepy = creepy;
    };
    
    this.getVillains = function() {
      return villains;
    };
    
    this.getSelectedVillain = function() {
      return selectedVillain;
    };
    
    function setSelectedVillain(villain) {
      selectedVillain = villain;
    }
    
    function getVillain(id) {
      var matchingVillains = villains.filter(function(villain) {
        return (villain.id === id);
      });
      if (matchingVillains.length === 1) {
        return matchingVillains[0];
      } else {
        throw new Error("No matching villains for id:", id);
      }
    }
  }]);
  //villainsController.$inject = ['villainService'];
//}());