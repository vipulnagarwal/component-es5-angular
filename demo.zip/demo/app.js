(function(){
  var app = angular.module("app", ['ui.router', 'oc.lazyLoad']);
    
    
    app.config(['$ocLazyLoadProvider', '$stateProvider', '$urlRouterProvider' , 
                function($ocLazyLoadProvider, $stateProvider, $urlRouterProvider) {
                    $urlRouterProvider.otherwise("/");
                    
            		console.log("app.js called");
            	  	  debugger;
            	  	  
    //Config For ocLazyLoading
    $ocLazyLoadProvider.config({
        'debug': true, // For debugging 'true/false'
        'events': true, // For Event 'true/false'
        'modules': [{ // Set modules initially
            name : 'heros', // module 1
            files: [
                    'app/features/heros/heros.component.js',
                   ]
        },{
            name : 'villains', // module 2
            files: [
                    'app/features/villains/villains.component.js',
                   ]
        }]
    });
        //Config/states of UI Router
    $stateProvider
    .state('heros', {
        url: "/heros",
        views : {
            "" : {
                templateUrl:"app/features/heros/heroTemplate.html"
            }
        },
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(['heros',
                                         'app/features/heros/heros.services.js',
                                         'app/features/heros/heros.controller.js',
                                         'app/features/heros/components/heroDetail/heroDetail.js',
                                         'app/features/heros/components/heroLeaderboard/heroLeaderboard.js',
                                         'app/features/heros/components/heroList/heroList.js'],
                                         {cache: false, serie: true}); // Resolve promise in series and remove cached script
            }]
        }
    })
    .state('villains', {
        url: "/villains",
        views : {
            "" : {
                templateUrl:"app/features/villains/villainTemplate.html"
            }
        },
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(['villains',
                                         'app/features/villains/villains.services.js',
                                         'app/features/villains/villains.controller.js',
                                         'app/features/villains/components/villainDetail/villainDetail.js',
                                         'app/features/villains/components/villainLeaderboard/villainLeaderboard.js',
                                         'app/features/villains/components/villainList/villainList.js'],
                                         {cache: false, serie: true}); // Resolve promise in series and remove cached script
            }]
        }
    });
    
    
/*    $stateProvider.state('parent', {
    	  url: "/",
    	  resolve: {
    	    loadMyService: ['$ocLazyLoad', function($ocLazyLoad) {
    	             return $ocLazyLoad.load('js/ServiceTest.js');
    	    }]
    	  }
    	})
    	.state('parent.child', {
    	    resolve: {
    	        test: ['loadMyService', '$ServiceTest', function(loadMyService, $ServiceTest) {
    	            // you can use your service
    	            $ServiceTest.doSomething();
    	        }]
    	    }
    	});*/
    
    
    
    
}]);
}());