# Refactoring your AngularJS 1.5 To Use Components

## Why?
* Try out an AngularJS 1.x architecture with one way data flow like Angular2 and React
* Part of preparing for an AngularJS 2 upgrade
* Try to build dumb, stateless components

## How?
* Follow the refactoring in previous [Part 3](http://plnkr.co/edit/pVzDsh?p=preview)
* Use the newly introduced .component method in Angular 1.5
* Use the '>' binding option for one way data binding
* Use callbacks for output, actions, events
* Convert the controllerAs and bindToController directive properties to component with bindings property
* Dumb directives that all inputs and outputs are communicated via bound arguments