(function(){
  var module = angular.module('heros');
  module.component('heroList', {
    bindings: { // bind right to this in controller
      heros: '=',
      onSelect: '&', // function takes single argument of heroId
      isSelected: '&' // function takes single argument of hero
    },
    templateUrl: 'app/heros/heroList/heroList.html',
    controller: function() {},
    //controllerAs: 'vm'
  });
}());