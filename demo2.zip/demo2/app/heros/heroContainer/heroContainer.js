(function(){
  var module = angular.module("heros");
  
  module.component("heroContainer", {
    bindings: {},
    controller: AppController,
    controllerAs: 'heroctrl',
    templateUrl: 'app/heros/heroContainer/heroContainer.html'
  });
  
  AppController.$inject = ['heroService'];
  
  function AppController(heroService) {
    var ctrl = this;
    
    // getting the heros (maybe from an API)
    var heros = heroService.query();
    
    // store the selected hero in the list to view details of
    var selectedhero;
    setSelectedhero(heros[0]);
  
    this.selecthero = function(heroId) {
      setSelectedhero(gethero(heroId));
    };
    
    this.isheroSelected = function(hero) {
      return (hero.id === selectedhero.id);
    };
    
    this.moreCreepy = function(heroId) {
      var hero = gethero(heroId);
      hero.creepy++;
    };
    
    this.lessCreepy = function(heroId) {
      var hero = gethero(heroId);
      hero.creepy--;
    };
    
    this.changeCreepy = function(heroId, creepy) {
      var hero = gethero(heroId);
      hero.creepy = creepy;
    };
    
    this.getheros = function() {
      return heros;
    };
    
    this.getSelectedhero = function() {
      return selectedhero;
    };
    
    function setSelectedhero(hero) {
      selectedhero = hero;
    }
    
    function gethero(id) {
      var matchingheros = heros.filter(function(hero) {
        return (hero.id === id);
      });
      if (matchingheros.length === 1) {
        return matchingheros[0];
      } else {
        throw new Error("No matching heros for id:", id);
      }
    }
  }
}());