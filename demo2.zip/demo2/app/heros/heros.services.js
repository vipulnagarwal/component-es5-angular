(function(){
  var module = angular.module('heros');
  
  module.service('heroService', function() {
    var data = [
      {
        id: "1",
        name: "Hero 1",
        superpower: "Body contortion",
        creepy: 0
      },
      {
        id: "2",
        name: "Hero 2",
        superpower: "Defying death",
        creepy: 0
      },
      {
        id: "3",
        name: "Hero 3",
        superpower: "Regenerate body parts",
        creepy: 0
      },
      {
        id: "4",
        name: "Hero 4",
        superpower: "Summons monsters",
        creepy: 0
      }
    ];
    
    this.query = function() {
      return data;
    };
    
    this.get = function(id) {
      return data.filter(function(item) {
        return item.id === id;
      })[0];
    };
  });
  
}());