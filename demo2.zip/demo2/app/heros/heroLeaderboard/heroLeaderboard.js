(function(){
  var module = angular.module('heros');
  module.component('heroLeaderboard', {
    bindings: { // bind right to this in controller
      heros: '='
    },
    templateUrl: 'app/heros/heroLeaderboard/heroLeaderboard.html',
    controller: function() {},
    //controllerAs: 'vm'
  });
}());