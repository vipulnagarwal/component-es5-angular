(function(){
  angular.module('heros', []);
}());