(function(){
  var module = angular.module('heros');
  module.component('heroDetail', {
    bindings: {
      //externalhero: '<hero', // let's make this one way data binding
      name: '<', // test one way databinding on a primitive, the hero name
      hero: '<', // test one way databinding on an object      
      onMoreCreepy: '&', // takes single argument of heroId
      onLessCreepy: '&',  // take single argument of heroId
      onChangeCreepy: '&' // takes two arguments, heroId and creepy
    },
    templateUrl: 'app/heros/heroDetail/heroDetail.html',
    controller: function($scope) {
      var vm = this;
      // You still have to copy hero to have one way databinding on objects
      /*
      vm.hero = angular.copy(vm.externalhero);
      $scope.$watch('vm.externalhero', function(newVal, oldVal) {
        vm.hero = angular.copy(newVal);
      }, true);
      */
    },
    //controllerAs: 'vm' // if we skip, will default to $ctrl
  });
}());