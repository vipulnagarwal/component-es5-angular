(function(){
  var module = angular.module('villains');
  module.component('villainLeaderboard', {
    bindings: { // bind right to this in controller
      villains: '='
    },
    templateUrl: 'app/villains/villainLeaderboard/villainLeaderboard.html',
    controller: function() {},
    controllerAs: 'vm'
  });
}());