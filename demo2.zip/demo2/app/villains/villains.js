(function(){
  angular.module('villains', []);
}());