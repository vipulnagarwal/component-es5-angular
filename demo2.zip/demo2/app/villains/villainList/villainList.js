(function(){
  var module = angular.module('villains');
  module.component('villainList', {
    bindings: { // bind right to this in controller
      villains: '=',
      onSelect: '&', // function takes single argument of villainId
      isSelected: '&' // function takes single argument of villain
    },
    templateUrl: 'app/villains/villainList/villainList.html',
    controller: function() {},
    controllerAs: 'vm'
  });
}());