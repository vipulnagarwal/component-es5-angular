(function(){
  var module = angular.module('villains');
  module.component('villainDetail', {
    bindings: {
      //externalVillain: '<villain', // let's make this one way data binding
      name: '<', // test one way databinding on a primitive, the villain name
      villain: '<', // test one way databinding on an object      
      onMoreCreepy: '&', // takes single argument of villainId
      onLessCreepy: '&',  // take single argument of villainId
      onChangeCreepy: '&' // takes two arguments, villainId and creepy
    },
    templateUrl: 'app/villains/villainDetail/villainDetail.html',
    controller: function($scope) {
      var vm = this;
      // You still have to copy villain to have one way databinding on objects
      /*
      vm.villain = angular.copy(vm.externalVillain);
      $scope.$watch('vm.externalVillain', function(newVal, oldVal) {
        vm.villain = angular.copy(newVal);
      }, true);
      */
    },
    controllerAs: 'vm' // if we skip, will default to $ctrl
  });
}());