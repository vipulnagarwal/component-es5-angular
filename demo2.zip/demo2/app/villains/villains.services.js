(function(){
  var module = angular.module('villains');
  
  module.service('villainService', function() {
    var data = [
      {
        id: "tooms",
        name: "Eugene Tooms",
        superpower: "Body contortion",
        creepy: 0
      },
      {
        id: "smokingman",
        name: "Cigarette-Smoking Man",
        superpower: "Defying death",
        creepy: 0
      },
      {
        id: "tanner",
        name: "Albert Tanner",
        superpower: "Regenerate body parts",
        creepy: 0
      },
      {
        id: "gogolak",
        name: "Gene Gogolak",
        superpower: "Summons monsters",
        creepy: 0
      }
    ];
    
    this.query = function() {
      return data;
    };
    
    this.get = function(id) {
      return data.filter(function(item) {
        return item.id === id;
      })[0];
    };
  });
  
}());