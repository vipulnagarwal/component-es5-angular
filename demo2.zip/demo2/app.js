(function(){
  var app = angular.module("app", ['ui.router', 'oc.lazyLoad']);
    
    
    app.config(['$ocLazyLoadProvider', '$stateProvider', '$urlRouterProvider' , 
                function($ocLazyLoadProvider, $stateProvider, $urlRouterProvider) {
                    $urlRouterProvider.otherwise("/");
    //Config For ocLazyLoading
    $ocLazyLoadProvider.config({
        'debug': true, // For debugging 'true/false'
        'events': true, // For Event 'true/false'
        'modules': [{ // Set modules initially
            name : 'heros', // State1 module
            files: [
                    'app/heros/heros.js',
                   ]
        },{
            name : 'villains', // State2 module
            files: [
                    'app/villains/villains.js',
                   ]
        }]
    });
        //Config/states of UI Router
    $stateProvider
    .state('heros', {
        url: "/heros",
        views : {
            "" : {
                templateUrl:"app/heros/heroindex.html"
            }
        },
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(['heros',
                                         'app/heros/heros.services.js',
                                         'app/heros/heroContainer/heroContainer.js',
                                         'app/heros/heroDetail/heroDetail.js',
                                         'app/heros/heroLeaderboard/heroLeaderboard.js',
                                         'app/heros/heroList/heroList.js'],
                                         {cache: false, serie: true}); // Resolve promise in series and remove cached script
            }]
        }
    })
    .state('villains', {
        url: "/villains",
        views : {
            "" : {
                templateUrl:"app/villains/villainindex.html"
            }
        },
        resolve: {
            loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                return $ocLazyLoad.load(['villains',
                                         'app/villains/villains.services.js',
                                         'app/villains/villainContainer/villainContainer.js',
                                         'app/villains/villainDetail/villainDetail.js',
                                         'app/villains/villainLeaderboard/villainLeaderboard.js',
                                         'app/villains/villainList/villainList.js'],
                                         {cache: false, serie: true}); // Resolve promise in series and remove cached script
            }]
        }
    });
    
    
/*    $stateProvider.state('parent', {
    	  url: "/",
    	  resolve: {
    	    loadMyService: ['$ocLazyLoad', function($ocLazyLoad) {
    	             return $ocLazyLoad.load('js/ServiceTest.js');
    	    }]
    	  }
    	})
    	.state('parent.child', {
    	    resolve: {
    	        test: ['loadMyService', '$ServiceTest', function(loadMyService, $ServiceTest) {
    	            // you can use your service
    	            $ServiceTest.doSomething();
    	        }]
    	    }
    	});*/
    
    
    
    
}]);
}());